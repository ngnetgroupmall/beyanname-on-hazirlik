@echo off
rem Beyanname On Hazirlik - tasinabilir paket. Bu dosyaya cift tiklayin (masaustune kisayolunu da olusturabilirsiniz).
start "" "%~dp0calisma\python\pythonw.exe" -X utf8 "%~dp0calisma\program\baslat.pyw"
